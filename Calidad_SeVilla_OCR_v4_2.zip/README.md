# Smart OCR v4.2 (AutoAlign)

- Detección de tabla (OpenCV.js) + warp.
- Reintento con recorte central.
- OCR por columnas N°, Descripción, Cantidad.
